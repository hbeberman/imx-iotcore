This firmware_fit.merged enables extra prints during U-Boot's init_sequence_r along with more debug prints in general

See the imx-iotcore GitHub for documentation on deploying firmware_fit.merged
https://github.com/ms-iot/imx-iotcore/blob/public_preview/Documentation/build-firmware.md#deploying-u-boot-and-op-tee-firmware_fitmerged-for-development
