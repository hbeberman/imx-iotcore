This experiment enables more verbose debug prints around the eMMC probe that
occurs in has_emmc in board_late_init.

firmware_fit.merged should be deployed to the SD card with DD
