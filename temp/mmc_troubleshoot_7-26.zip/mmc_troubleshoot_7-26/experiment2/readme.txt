This experiment has desabled the "has_emmc" check in U-Boot and UEFI is
configured with security disabled. This means there's no fTPM trusted
application that will attempt to access the eMMC and hang the system if it
fails.

firmware_fit.merged should be deployed to the SD card with DD
uefi.fit should be copied to the EFI partition on the SD card.
